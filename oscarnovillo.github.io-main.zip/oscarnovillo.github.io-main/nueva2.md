---
layout: page
permalink: /yamal.html
title: Categories
category: boondys, costras

---

<ul>
  {% for post in site.posts %}
    <li>
      <a href="{{ post.url }}">{{ post.title }}</a>
    </li>
  {% endfor %}
</ul>